FA Umut Merkezi — ücretsiz statik site paketi

GitHub Pages için:
1. Bu paketteki index.html ve styles.css dosyalarını repository'nin kök dizinine yükleyin.
2. GitHub web sitesinde repository > Settings > Pages bölümüne gidin.
3. Source olarak Deploy from a branch seçin.
4. Branch: main, folder: / (root) seçip Save'e basın.
5. GitHub Pages yayın adresi oluşacaktır.

Not: Bu paket bağımsız statik sürümdür; Lovable aboneliği gerektirmez.
